<?php $__env->startSection('title'); ?>
    Faculty Table
<?php $__env->stopSection(); ?>

<?php $__env->startSection('topnav'); ?>
    <a href="<?php echo e(route('admin.index')); ?>" class="inactive">Dashboard</a>
    <a href="<?php echo e(route('admin.archives')); ?>" class="inactive">Archives</a>
    <a href="<?php echo e(route('admin.checker')); ?>" class="inactive">Checker</a>
    <a href="<?php echo e(route('admin.student')); ?>" class="inactive">Student</a>
    <a href="<?php echo e(route('admin.faculty')); ?>" class="actives">Faculty</a>
    <a href="<?php echo e(route('admin.admin')); ?>" class="inactive">Admin</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <br>


    <div class="table-wrapper">

        <table class="fl-table">
            <a href="<?php echo e(route('admin.addUser', ['user' => 'faculty'])); ?>" class="glowbtn">Add Faculty</a>

            <br><br><br>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Password</th>
                    <th>Full Name</th>
                    <th> Views </th>
                    <th> Edit </th>
                    
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $faculty; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fac): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>

                        <td><?php echo e($fac->EMP_ID); ?></td>
                        
                        <td><?php echo e(decrypt($fac->PASSWORD)); ?></td>
                        <td><?php echo e($fac->NAME); ?></td>
                        <td><a href="/usercc/<?php echo e($fac->USER_ID_EMP); ?>" class="glowbtn">view</a></td>

                        <td><a href="<?php echo e(route('admin.edit', ['USER_ID_EMP' => $fac->USER_ID_EMP])); ?>"
                                class="glowbtn">edit</a></td>
                        <td>
                            
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php echo e($faculty->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hehe\Desktop\Fnl_CAPSTONE_CORNER\resources\views/adminFacultyTB.blade.php ENDPATH**/ ?>