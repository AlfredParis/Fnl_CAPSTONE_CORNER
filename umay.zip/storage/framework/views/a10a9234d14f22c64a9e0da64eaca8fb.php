<?php $__env->startSection('title'); ?>
    login
<?php $__env->stopSection(); ?>

<?php $__env->startSection('topnav'); ?>
    <a href="<?php echo e(route('root')); ?>" class="active">login</a>
    <a href="<?php echo e(route('userCC.create')); ?>" class="inactive">regsiter</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <br>
    <div class="container">
        <form class="" action="<?php echo e(route('userCC.index')); ?>" method="get">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label for="userID">User ID</label>
                <input type="text" class="form-control" placeholder="Enter ID" name="userID" value="<?php echo e(old('userID')); ?>"
                    required>
            </div>
            <?php if(Session::get('messageid')): ?>
                <span class="msgAlert"><?php echo e(Session::get('messageid')); ?></span>
            <?php else: ?>
                <br>
            <?php endif; ?>



            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" class="form-control" placeholder="Enter Password" name="password"
                    value="<?php echo e(old('password')); ?>" id="myInput" required>
            </div>
            <?php if(Session::get('messagepass')): ?>
                <span class="msgAlert"><?php echo e(Session::get('messagepass')); ?></span>
            <?php else: ?>
                <br>
            <?php endif; ?>

            <div class="showpass">
                <input type="checkbox" onclick="myFunction()"> Show Password
            </div>
            

            <div style="text-align: center">
                <button type="submit" class="btn btn-primary">Login</button>
                <br>
            </div>
            
            <div class="line">____________________________________________________</div>
            <br>
            
            
            <DIV class="sec-btn"><a href="<?php echo e(route('userCC.create')); ?>" class="btn btn-secondary">Create an Account</a>
            </DIV>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.homeLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hehe\Desktop\Fnl_CAPSTONE_CORNER\resources\views/login.blade.php ENDPATH**/ ?>