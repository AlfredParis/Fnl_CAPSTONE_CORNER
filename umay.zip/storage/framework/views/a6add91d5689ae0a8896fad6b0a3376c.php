<?php $__env->startSection('title'); ?>
    Admin Table
<?php $__env->stopSection(); ?>

<?php $__env->startSection('topnav'); ?>
    <a href="<?php echo e(route('admin.index')); ?>" class="inactive">Dashboard</a>
    <a href="<?php echo e(route('admin.archives')); ?>" class="inactive">Archives</a>
    <a href="<?php echo e(route('admin.checker')); ?>" class="inactive">Checker</a>
    <a href="<?php echo e(route('admin.student')); ?>" class="inactive">Student</a>
    <a href="<?php echo e(route('admin.faculty')); ?>" class="inactive">Faculty</a>
    <a href="<?php echo e(route('admin.admin')); ?>" class="actives">Admin</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <br>


    <div class="table-wrapper">

        <table class="fl-table">
            <a href="<?php echo e(route('admin.addUser', ['user' => 'admin'])); ?>" class="glowbtn">Add admin</a>

            <br><br>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Full Name</th>
                    <th>Password</th>
                    <th> Views </th>
                    <th> Edit </th>
                    
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $admin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>

                        <td><?php echo e($adm->EMP_ID); ?></td>
                        <td><?php echo e($adm->NAME); ?></td>
                        <td><?php echo e(decrypt($adm->PASSWORD)); ?></td>
                        <td><a href="/usercc/<?php echo e($adm->USER_ID_EMP); ?>" class="glowbtn">view</a></td>

                        <td><a href="<?php echo e(route('admin.edit', ['USER_ID_EMP' => $adm->USER_ID_EMP])); ?>"
                                class="glowbtn">edit</a></td>
                        
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    </div>
    <div class="pagination"><?php echo e($admin->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hehe\Desktop\Fnl_CAPSTONE_CORNER\resources\views/adminAdminTB.blade.php ENDPATH**/ ?>