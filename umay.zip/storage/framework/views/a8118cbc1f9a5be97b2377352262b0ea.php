<?php $__env->startSection('title'); ?>
    Title Checker
<?php $__env->stopSection(); ?>

<?php $__env->startSection('topnav'); ?>
    <a href="<?php echo e(route('admin.index')); ?>" class="inactive">
        Dashboard</a>
    <a href="<?php echo e(route('admin.archives')); ?>" class="inactive">Archives</a>
    <a href="<?php echo e(route('admin.checker')); ?>" class="actives">Checker</a>
    <a href="<?php echo e(route('admin.student')); ?>" class="inactive">Student</a>
    <a href="<?php echo e(route('admin.faculty')); ?>" class="inactive">Faculty</a>
    <a href="<?php echo e(route('admin.admin')); ?>" class="inactive">Admin</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>

    <div class="checker">

        <div class="frm">
            <div class="chkContainier">
                <form action="<?php echo e(route('admin.words')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="formGroup">
                        <label for="user_input">Enter a your title:</label>
                        <input class="formControl" type="text" name="user_input" id="user_input">
                    </div>
                    <div class="formGroup">
                        <label for="abs">Enter a your abstract:</label>
                        <textarea class="abstract" type="text" name="abs" id="abs"></textarea>
                    </div>
                    <button type="submit" class="btn btnSecondary">Find</button>
                </form>
            </div>
        </div>
        <div class="check">
            <div class="chktable-wrapper">


                <?php if(isset($similarTitles) && count($similarTitles) > 0): ?>
                    <table class="fl-chktable">
                        <thead>
                            <tr>
                                <th>Similar Titles</th>
                                <th>Similarity Percentage</th>
                                <th>Similar Words</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $similarTitles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $similarTitle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th><?php echo e($similarTitle['title']); ?></th>
                                    <th><?php echo e($similarTitle['average_similarity_percentage']); ?>%</th>


                                    <th>
                                        <?php if(count($similarTitle['similar_words']) > 0): ?>
                                            <ul>
                                                <?php $__currentLoopData = $similarTitle['similar_words']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $similarWord): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><?php echo e($similarWord); ?></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        <?php else: ?>
                                            No similar words found.
                                        <?php endif; ?>
                                    </th>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <strong class="chtitle">No similar titles found!</strong>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hehe\Desktop\Fnl_CAPSTONE_CORNER\resources\views/adminChecker.blade.php ENDPATH**/ ?>