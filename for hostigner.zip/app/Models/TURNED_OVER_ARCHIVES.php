<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TURNED_OVER_ARCHIVES extends Model
{
    use HasFactory;
    protected $fillable = ['PUB_STAT'];
}
