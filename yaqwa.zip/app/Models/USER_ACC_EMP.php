<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class USER_ACC_EMP extends Model
{
    use HasFactory;
}
