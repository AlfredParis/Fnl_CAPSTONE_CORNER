<?php $__env->startSection('title'); ?>
    Student Table
<?php $__env->stopSection(); ?>

<?php $__env->startSection('topnav'); ?>
    <a href="<?php echo e(route('admin.index')); ?>" class="inactive">Dashboard</a>
    <a href="<?php echo e(route('admin.archives')); ?>" class="inactive">Archives</a>
    <a href="<?php echo e(route('admin.checker')); ?>" class="inactive">Checker</a>
    <a href="<?php echo e(route('admin.student')); ?>" class="actives">Student</a>
    <a href="<?php echo e(route('admin.faculty')); ?>" class="inactive">Faculty</a>
    <a href="<?php echo e(route('admin.admin')); ?>" class="inactive">Admin</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <br>
    <div class="top-left-anchor">


        <form action="<?php echo e(route('admin.import.excel')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>



            <input type="file" style=" margin-left: 1%;" name="excel_file" id="excel_file" accept=".xlsx, .xls" required>

            <br> <br>
            <button type="submit" class="glowbtn">Import Excel Student</button>

        </form>
    </div><br>


    <div class="table-wrapper">

        <table class="fl-table"><br>
            <a href="<?php echo e(route('admin.addUser', ['user' => 'student'])); ?>" class="glowbtn">Add Student</a>



            <br><br>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Full Name</th>
                    <th>Password</th>

                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $SN; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>

                        <td><?php echo e($student->S_ID); ?></td>
                        <td><?php echo e($student->NAME); ?></td>
                        <td><?php echo e($student->C_DESC); ?></td>




                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php echo e($SN->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hehe\Desktop\Fnl_CAPSTONE_CORNER\resources\views/adminStudentTB.blade.php ENDPATH**/ ?>