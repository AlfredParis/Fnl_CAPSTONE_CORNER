<?php $__env->startSection('title'); ?>
    Archive Table
<?php $__env->stopSection(); ?>

<?php $__env->startSection('topnav'); ?>
    <a href="<?php echo e(route('admin.index')); ?>" class="inactive">Dashboard</a>
    <a href="<?php echo e(route('admin.archives')); ?>" class="actives">Archives</a>
    <a href="<?php echo e(route('admin.checker')); ?>" class="inactive">Checker</a>
    <a href="<?php echo e(route('admin.student')); ?>" class="inactive">Student</a>
    <a href="<?php echo e(route('admin.faculty')); ?>" class="inactive">Faculty</a>
    <a href="<?php echo e(route('admin.admin')); ?>" class="inactive">Admin</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <br>

    <div class="table-wrapper">
        <a href="<?php echo e(route('admin.addArch')); ?>" class="glowbtn">Add Archive</a>



        <br><br>
        <table class="fl-table">
            <thead>
                <tr>
                    <th>Archive ID</th>
                    <th>Archive Title</th>

                    <th> Documentation</th>
                    <th> Documentation</th>
                    <th> GitHub Repository </th>
                    <th> Views </th>
                    <th> Edit </th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $arch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $archive): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>

                        <td><?php echo e($archive->ARCH_ID); ?></td>
                        <td><?php echo e($archive->ARCH_NAME); ?></td>
                        <td><a href="#"
                                onclick="openPDF('<?php echo e(asset('storage/pdfs/' . $archive->PDF_FILE)); ?>');"><?php echo e($archive->PDF_FILE); ?></a>
                        </td>
                        <td><?php echo e($archive->GITHUB_LINK); ?></td>
                        <td><a href="/admin/<?php echo e($archive->ARCH_ID); ?>" class="glowbtn">view</a></td>

                        <td><a href="<?php echo e(route('admin.editArch', ['ARCH_ID' => $archive->ARCH_ID])); ?>"
                                class="glowbtn">edit</a>
                        </td>
                        <td><?php echo e($archive->AUTHOR_ID); ?></td>
                        

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div> <?php echo e($arch->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hehe\Desktop\Fnl_CAPSTONE_CORNER\resources\views/adminArchive.blade.php ENDPATH**/ ?>