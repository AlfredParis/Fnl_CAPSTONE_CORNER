<?php $__env->startSection('title'); ?>
    Admin Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('topnav'); ?>
    <a href="<?php echo e(route('admin.index')); ?>" class="actives">Dashboard</a>
    <a href="<?php echo e(route('admin.archives')); ?>" class="inactive">Archives</a>
    <a href="<?php echo e(route('admin.checker')); ?>" class="inactive">Checker</a>
    <a href="<?php echo e(route('admin.student')); ?>" class="inactive">Student</a>
    <a href="<?php echo e(route('admin.faculty')); ?>" class="inactive">Faculty</a>
    <a href="<?php echo e(route('admin.admin')); ?>" class="inactive">Admin</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <br>
    <div class="dashB">

        <div class="admin">
            <img class="dashimg" src="<?php echo e(asset('images/admin.png')); ?>" alt="">
            <p> Admin: </p>
            <div class="num"><?php echo e($tl_admin); ?></div>
        </div>
        <div class="stud">
            <img class="dashimg" src="<?php echo e(asset('images/student.png')); ?>" alt="">
            <p> Student: </p>
            <div class="num"><?php echo e($tl_stud); ?></div>
        </div>
        <div class="fac">
            <img class="dashimg" src="<?php echo e(asset('images/fac.png')); ?>" alt="">
            <p> Faculty: </p>
            <div class="num"><?php echo e($tl_fac); ?></div>
        </div>
        <div class="arch">
            <img class="dashimg" src="<?php echo e(asset('images/arch.png')); ?>" alt="">
            <p> Archives: </p>
            <div class="num"><?php echo e($tl_arch); ?></div>
        </div>







    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hehe\Desktop\Fnl_CAPSTONE_CORNER\resources\views/adminDashB.blade.php ENDPATH**/ ?>