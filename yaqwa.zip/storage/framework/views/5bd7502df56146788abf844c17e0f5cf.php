<!DOCTYPE html>
<html>

<head>
    <title>User Data PDF</title>
</head>

<body>
    <h1>User Data PDF</h1>
    <strong>Note: Please dowload this PDF or right down your user id and password </strong>
    <p>This is the user data in PDF format:</p>

    <h1>Student Information</h1>
    <p><strong>Student ID:</strong> <?php echo e($user->S_ID); ?></p>
    <p><strong>Name:</strong> <?php echo e($user->NAME); ?></p>
    <p><strong>Course ID:</strong> <?php echo e($user->C_ID); ?></p>
    <p><strong>Course ID:</strong> <?php echo e($result->C_DESC); ?></p>
    
    
</body>

</html>
<?php /**PATH C:\Users\hehe\Desktop\Fnl_CAPSTONE_CORNER\resources\views/pdf/template.blade.php ENDPATH**/ ?>